@echo off
set X2MD_APP_DIR=%APPDATA%\X2MD
node app/main/index.ts
