X2MD Windows Lite v3.0.0

Run start-windows.bat after installing Node.js 22+.
Supports ping/config/save/settings/autostart API surface.
