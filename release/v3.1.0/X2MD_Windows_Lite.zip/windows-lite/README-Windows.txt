X2MD Windows Lite v3.1.0

Run start-windows.bat after installing Node.js 22+.
Supports ping/config/save/settings/autostart API surface.
